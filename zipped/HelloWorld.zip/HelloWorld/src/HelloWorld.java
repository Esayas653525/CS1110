/* PROJECT:  HelloWorld
 * AUTHOR:  Dr. Kaminski
 * DESCRIPTION:  Program displays Hello World to IDE output window.
 ****************************************************************************/

public class HelloWorld {
    
    public static void main(String[] args) {
        
        System.out.println("Hello World");  
    }
}
